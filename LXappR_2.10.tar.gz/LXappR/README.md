# LXappR
LXappR can be used for nmr analysis et.al.,
